package mx.com.prueba.pedidos.dto;

import java.io.Serializable;
import java.util.List;

import mx.com.prueba.pedidos.model.DetallePedido;
import mx.com.prueba.pedidos.model.Pedidos;

public class PedidosDTOResponse extends DetallePedido implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8613437931694823484L;

	private List<Pedidos> listPedidos;


	public List<Pedidos> getListPedidos() {
		return listPedidos;
	}

	public void setListPedidos(List<Pedidos> listPedidos) {
		this.listPedidos = listPedidos;
	}

	

}
