package mx.com.prueba.pedidos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = { "mx.com.prueba.pedidos" })
public class TpPedidosRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpPedidosRestApplication.class, args);

	}

}
