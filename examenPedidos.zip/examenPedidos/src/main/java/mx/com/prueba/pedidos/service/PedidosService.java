package mx.com.prueba.pedidos.service;

import mx.com.prueba.pedidos.dto.PedidosDTOResponse;

public interface PedidosService {

	public PedidosDTOResponse getPedidos() throws Exception;

}
