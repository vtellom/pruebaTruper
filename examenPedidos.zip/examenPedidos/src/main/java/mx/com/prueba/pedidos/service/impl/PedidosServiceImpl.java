package mx.com.prueba.pedidos.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.prueba.pedidos.dao.PedidosDAO;
import mx.com.prueba.pedidos.dto.PedidosDTOResponse;
import mx.com.prueba.pedidos.model.DetallePedido;
import mx.com.prueba.pedidos.model.Pedidos;
import mx.com.prueba.pedidos.service.PedidosService;

@Service
public class PedidosServiceImpl implements PedidosService {

	@Autowired
	private PedidosDAO pedidosDAOImpl;

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public PedidosDTOResponse getPedidos() throws Exception {

		List<Pedidos> listPedidosResponse = new ArrayList<Pedidos>();
		List<DetallePedido> listDetallePedidosResponse = new ArrayList<DetallePedido>();
		PedidosDTOResponse pedidoDTOResponse = new PedidosDTOResponse();

		try {

			List<Pedidos> pedidos = new ArrayList<Pedidos>();
			List<DetallePedido> detalle = new ArrayList<DetallePedido>();

			pedidos = this.pedidosDAOImpl.getPedidos();
			detalle = this.pedidosDAOImpl.getDetallePedidos();

			for (Pedidos pedido : pedidos) {

				Pedidos pedidoResponse = new Pedidos();

				
				pedidoResponse.setId(pedido.getId());
				pedidoResponse.setTotal(pedido.getTotal());
				pedidoResponse.setDateSale(pedido.getDateSale());
				

				listPedidosResponse.add(pedidoResponse);

			}
			
			for (DetallePedido detallePedido : detalle) {

				DetallePedido detallePedidoResponse = new DetallePedido();

				detallePedidoResponse.setIdPedido(detallePedido.getIdPedido());
				detallePedidoResponse.setAmout(detallePedido.getAmout());
				detallePedidoResponse.setSku(detallePedido.getSku());
				detallePedidoResponse.setPrice(detallePedido.getPrice());
				
				
				

				listDetallePedidosResponse.add(detallePedidoResponse);

			}

			pedidoDTOResponse.setListPedidos(pedidos);
			//pedidoDTOResponse.setListDetallePedidos(detalle);

		} catch (Exception e) {

			logger.error("This is an ERROR message - getPedidos: " + e);
		}

		return pedidoDTOResponse;
	}

}
