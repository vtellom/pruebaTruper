package mx.com.prueba.pedidos.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import mx.com.prueba.pedidos.dto.PedidosDTOResponse;
import mx.com.prueba.pedidos.service.PedidosService;

@RestController
public class PedidosController {

	@Autowired
	private PedidosService pedidosServiceImpl;

	@RequestMapping(value = "/findPedidos", method = RequestMethod.POST)
	@PostMapping
	public ResponseEntity<PedidosDTOResponse> findPedidos() throws Exception {
		PedidosDTOResponse responseManager = this.pedidosServiceImpl.getPedidos();
		return new ResponseEntity<@Valid PedidosDTOResponse>(responseManager, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/findAllPedidos", method = RequestMethod.GET)
	@PostMapping
	public ResponseEntity<PedidosDTOResponse> findAllPedidos() throws Exception {
		PedidosDTOResponse responseManager = this.pedidosServiceImpl.getPedidos();
		return new ResponseEntity<@Valid PedidosDTOResponse>(responseManager, HttpStatus.OK);
	}

}