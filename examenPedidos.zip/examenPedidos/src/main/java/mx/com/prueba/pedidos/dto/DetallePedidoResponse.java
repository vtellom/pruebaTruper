package mx.com.prueba.pedidos.dto;

import java.io.Serializable;
import java.util.List;

import mx.com.prueba.pedidos.model.DetallePedido;

public class DetallePedidoResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<DetallePedido> listDetallePedidos;

	public List<DetallePedido> getListDetallePedidos() {
		return listDetallePedidos;
	}

	public void setListDetallePedidos(List<DetallePedido> listDetallePedidos) {
		this.listDetallePedidos = listDetallePedidos;
	}

}
