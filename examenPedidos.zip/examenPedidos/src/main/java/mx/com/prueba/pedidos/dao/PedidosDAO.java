package mx.com.prueba.pedidos.dao;

import java.util.List;

import mx.com.prueba.pedidos.model.DetallePedido;
import mx.com.prueba.pedidos.model.Pedidos;

public interface PedidosDAO {

	public List<Pedidos> getPedidos();
	
	public List<DetallePedido> getDetallePedidos();

}
