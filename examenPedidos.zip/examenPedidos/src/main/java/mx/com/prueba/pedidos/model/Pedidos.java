package mx.com.prueba.pedidos.model;

import java.util.Date;

public class Pedidos extends DetallePedido{

	private int id;
	private double total;
	private Date dateSale;

	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public Date getDateSale() {
		return dateSale;
	}

	public void setDateSale(Date dateSale) {
		this.dateSale = dateSale;
	}

}
