package mx.com.prueba.pedidos.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import mx.com.prueba.pedidos.constant.Constant;
import mx.com.prueba.pedidos.dao.PedidosDAO;
import mx.com.prueba.pedidos.model.DetallePedido;
import mx.com.prueba.pedidos.model.Pedidos;

@Repository
public class PedidosDAOImpl implements PedidosDAO {

	@Autowired
	@Qualifier("jdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	public List<Pedidos> getPedidos() {

		List<Pedidos> returnProducto = new ArrayList<Pedidos>();
		List<DetallePedido> returnDetalleProducto = new ArrayList<DetallePedido>();
		returnProducto = jdbcTemplate.query(Constant.SQL_getPedidos, new Object[] {}, new RowMapper<Pedidos>() {

			public Pedidos mapRow(ResultSet rs, int i) throws SQLException {
				Pedidos pedido = new Pedidos();

				pedido.setId(rs.getInt("id"));
				pedido.setTotal(rs.getDouble("total"));
				pedido.setDateSale(rs.getDate("date_sale"));

				
				  pedido.setIdPedido(rs.getInt("ID_PEDIDO"));
				  pedido.setSku(rs.getString("SKU"));
				  pedido.setAmout(rs.getDouble("AMOUT"));
				  pedido.setPrice(rs.getDouble("PRICE"));
				 
				return pedido;
			}
		});

		return returnProducto;

	}

	public List<DetallePedido> getDetallePedidos() {

		List<DetallePedido> returnDetalleProducto = new ArrayList<DetallePedido>();
		returnDetalleProducto = jdbcTemplate.query(Constant.SQL_getDetallePedidos, new Object[] {},
				new RowMapper<DetallePedido>() {

					public DetallePedido mapRow(ResultSet rs, int i) throws SQLException {
						DetallePedido detalle = new DetallePedido();

						detalle.setIdPedido(rs.getInt("ID_PEDIDO"));
						detalle.setSku(rs.getString("SKU"));
						detalle.setAmout(rs.getDouble("AMOUT"));
						detalle.setPrice(rs.getDouble("PRICE"));

						return detalle;
					}
				});

		return returnDetalleProducto;

	}

}
