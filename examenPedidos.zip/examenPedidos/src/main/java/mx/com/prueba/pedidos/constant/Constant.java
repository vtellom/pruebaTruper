package mx.com.prueba.pedidos.constant;

public final class Constant {

//	B.D datahub
	public static final String SQL_getPedidos ="SELECT a.id,a.total,a.date_sale,b.ID_PEDIDO,b.SKU,b.AMOUT,b.PRICE \r\n" + 
			"FROM examen.pedidos_w a, examen.pedidos_detalle_w b\r\n" + 
			"where a.ID = b.ID";
	
	public static final String SQL_getDetallePedidos ="SELECT ID_PEDIDO,SKU,AMOUT,PRICE FROM examen.pedidos_detalle_w";
	
	
 

}